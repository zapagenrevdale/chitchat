import { describe, expect, it } from "vitest";

import introductions from "../../../public/audio/chit/manifest.json";
import { personalizeWelcome } from "./onboarding-introduction";

describe("saved introduction timestamps", () => {
  it.each(introductions)(
    "$language preserves its complete text and valid audio timing",
    (sample) => {
      expect(sample.words.length).toBeGreaterThan(0);
      expect(sample.words.map((word) => word.text).join("")).toBe(sample.text);
      expect(
        sample.words.every(
          (word, index) =>
            Number.isFinite(word.start) &&
            Number.isFinite(word.end) &&
            word.start >= (sample.words[index - 1]?.end ?? 0) &&
            word.end >= word.start &&
            word.end <= sample.seconds + 0.1
        )
      ).toBeTruthy();
    }
  );
});

describe("personalized welcome", () => {
  it("keeps name placement and timing when the greeting spans several words", () => {
    const words = personalizeWelcome(
      [
        { text: "Bien ", start: 0.2 },
        { text: "venido! ", start: 0.5 },
        { text: "Vamos.", start: 1.2 },
      ],
      "Bien venido!",
      "¡Hola, Sam!"
    );
    expect(words.map(({ text }) => text).join("")).toBe("¡Hola, Sam! Vamos.");
    expect(words.map(({ start }) => start)).toStrictEqual([0.2, 0.5, 1.2]);
  });
});
