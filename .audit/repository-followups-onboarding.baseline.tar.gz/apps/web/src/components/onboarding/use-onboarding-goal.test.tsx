import type { OnboardingTurn } from "@chitchat/contracts/onboarding";
import { act, cleanup, renderHook } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { replyToOnboarding } from "@/lib/practice-api";

import { useOnboardingGoal } from "./use-onboarding-goal";

vi.mock(import("@/lib/practice-api"), () => ({
  replyToOnboarding: vi.fn<typeof replyToOnboarding>(),
}));
const ready: OnboardingTurn = {
  status: "ready",
  reply: "Got it—you want to keep conversations going.",
  goal: "Keep conversations going with new people.",
  suggestedSkills: ["conversation-flow"],
};
const clarify: OnboardingTurn = {
  status: "clarify",
  reply: "When does talking feel hardest?",
  goal: "",
  suggestedSkills: [],
};
function setup() {
  const onReady = vi.fn<(turn: OnboardingTurn) => void>();
  const onReply = vi.fn<(messages: unknown) => void>();
  return {
    onReady,
    onReply,
    ...renderHook(() =>
      useOnboardingGoal({
        initialMessages: [],
        name: "Alex",
        language: "English",
        onReply,
        onReady,
      })
    ),
  };
}
describe("onboarding clarification turns", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.clearAllMocks();
    vi.mocked(replyToOnboarding).mockResolvedValue(ready);
  });
  afterEach(() => {
    cleanup();
    vi.useRealTimers();
  });

  it("shows an acknowledgment before advancing without confirmation", async () => {
    const { result, onReady } = setup();
    await act(() => {
      void result.current.submit("Keep conversations going");
    });
    expect(result.current.messages.at(-1)?.text).toBe(ready.reply);
    expect(onReady).not.toHaveBeenCalled();
    await act(() => vi.advanceTimersByTimeAsync(1800));
    expect(onReady).toHaveBeenCalledExactlyOnceWith(ready);
  });

  it("includes both sides of a clarification in the next request", async () => {
    vi.mocked(replyToOnboarding).mockResolvedValueOnce(clarify);
    const { result, onReady } = setup();
    await act(() => {
      void result.current.submit("idk");
    });
    await act(() => vi.advanceTimersByTimeAsync(1800));
    expect(onReady).not.toHaveBeenCalled();
    await act(() => {
      void result.current.submit("Meeting new people");
    });
    expect(replyToOnboarding).toHaveBeenLastCalledWith(
      {
        name: "Alex",
        language: "English",
        messages: [
          { role: "user", text: "idk" },
          { role: "assistant", text: clarify.reply },
          { role: "user", text: "Meeting new people" },
        ],
      },
      expect.any(AbortSignal)
    );
    await act(() => vi.advanceTimersByTimeAsync(1800));
    expect(onReady).toHaveBeenCalledOnce();
  });

  it("retries failed replies without duplicating the user's message", async () => {
    vi.mocked(replyToOnboarding).mockRejectedValueOnce(new Error("Offline"));
    const { result } = setup();
    await act(() => result.current.submit("Meet people"));
    expect(result.current.error).toBeTruthy();
    await act(() => {
      void result.current.submit("Meet people");
    });
    expect(
      vi.mocked(replyToOnboarding).mock.calls[1]?.[0].messages
    ).toHaveLength(1);
  });

  it("cancels pending advancement when the user goes back", async () => {
    const { result, onReady } = setup();
    await act(() => {
      void result.current.submit("Meet people");
    });
    act(() => result.current.reset());
    await act(() => vi.advanceTimersByTimeAsync(5000));
    expect(onReady).not.toHaveBeenCalled();
    expect(result.current.messages).toStrictEqual([]);
  });

  it("ignores a late model response after unmount", async () => {
    let finish: ((turn: OnboardingTurn) => void) | undefined;
    vi.mocked(replyToOnboarding).mockReturnValue(
      // oxlint-disable-next-line promise/avoid-new -- Simulate a pending network request.
      new Promise((resolve) => {
        finish = resolve;
      })
    );
    const { result, unmount, onReady, onReply } = setup();
    act(() => {
      void result.current.submit("Meet people");
    });
    unmount();
    await act(() => finish?.(ready));
    expect(onReady).not.toHaveBeenCalled();
    expect(onReply).not.toHaveBeenCalled();
  });
});
