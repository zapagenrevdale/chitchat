import type {
  OnboardingMessage,
  OnboardingTurn,
  OnboardingTurnRequest,
} from "@chitchat/contracts/onboarding";
import { useCallback, useEffect, useRef, useState } from "react";

import { replyToOnboarding } from "@/lib/practice-api";

function leaveTimeToRead(signal: AbortSignal) {
  // A cancellable reading delay before an automatic screen transition.
  // oxlint-disable-next-line promise/avoid-new
  return new Promise<void>((resolve) => {
    let timer = 0;
    function done() {
      window.clearTimeout(timer);
      signal.removeEventListener("abort", done);
      resolve();
    }
    timer = window.setTimeout(done, 1800);
    signal.addEventListener("abort", done, { once: true });
  });
}

export function useOnboardingGoal({
  initialMessages,
  name,
  language,
  onReply,
  onReady,
}: {
  initialMessages: OnboardingMessage[];
  name: string;
  language: OnboardingTurnRequest["language"];
  onReply: (messages: OnboardingMessage[], turn: OnboardingTurn) => void;
  onReady: (turn: OnboardingTurn) => void;
}) {
  const [messages, setMessages] = useState(initialMessages);
  const history = useRef(initialMessages);
  const [phase, setPhase] = useState<"idle" | "thinking">("idle");
  const [error, setError] = useState(false);
  const [result, setResult] = useState<OnboardingTurn | null>(null);
  const active = useRef<AbortController | null>(null);
  const stop = useCallback(() => {
    active.current?.abort();
    active.current = null;
  }, []);
  useEffect(() => {
    window.addEventListener("pagehide", stop);
    return () => {
      window.removeEventListener("pagehide", stop);
      stop();
    };
  }, [stop]);

  function reset() {
    stop();
    history.current = [];
    setMessages([]);
    setPhase("idle");
    setResult(null);
    setError(false);
  }

  async function submit(answer: string) {
    if (!answer.trim() || active.current || history.current.length >= 6) {
      return;
    }
    const controller = new AbortController();
    active.current = controller;
    const { signal } = controller;
    const next: OnboardingMessage[] = [
      ...history.current,
      { role: "user", text: answer.trim() },
    ];
    setMessages(next);
    setPhase("thinking");
    setError(false);
    setResult(null);
    try {
      const turn = await replyToOnboarding(
        { name, language, messages: next },
        signal
      );
      signal.throwIfAborted();
      const conversation: OnboardingMessage[] = [
        ...next,
        { role: "assistant", text: turn.reply },
      ];
      history.current = conversation;
      setMessages(conversation);
      onReply(conversation, turn);
      setResult(turn);
      await leaveTimeToRead(signal);
      signal.throwIfAborted();
      if (turn.status !== "clarify") {
        onReady(turn);
      }
    } catch {
      if (!signal.aborted) {
        setError(true);
      }
    }
    if (active.current === controller) {
      active.current = null;
      setPhase("idle");
    }
  }

  return {
    messages,
    phase,
    error,
    result,
    submit,
    reset,
    stop,
  };
}
