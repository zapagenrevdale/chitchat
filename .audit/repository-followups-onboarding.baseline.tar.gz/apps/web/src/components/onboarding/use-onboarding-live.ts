import type { PracticeLanguage } from "@chitchat/contracts";
import type {
  OnboardingMessage,
  OnboardingTurn,
} from "@chitchat/contracts/onboarding";
import {
  useCallback,
  useEffect,
  useEffectEvent,
  useRef,
  useState,
} from "react";

import { OnboardingLive } from "@/lib/onboarding-live";
import type {
  OnboardingLiveMessage,
  OnboardingLivePhase,
} from "@/lib/onboarding-live";

export function useOnboardingLive({
  name,
  language,
  onMessages,
  autoStart = false,
}: {
  name: string;
  language: PracticeLanguage;
  onMessages: (messages: OnboardingMessage[]) => void;
  autoStart?: boolean;
}) {
  const [phase, setPhase] = useState<OnboardingLivePhase>("idle");
  const [messages, setMessages] = useState<OnboardingLiveMessage[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<OnboardingTurn | null>(null);
  const session = useRef<OnboardingLive | null>(null);
  const startOnMount = useRef(autoStart);
  const reportMessages = useRef(onMessages);
  useEffect(() => {
    reportMessages.current = onMessages;
  }, [onMessages]);
  const close = useCallback(() => {
    // Invalidate first: disposing audio and sockets may synchronously fire events.
    const previous = session.current;
    session.current = null;
    previous?.close();
  }, []);
  const stop = useCallback(() => {
    close();
    setPhase("idle");
  }, [close]);

  function start() {
    close();
    setMessages([]);
    onMessages([]);
    setError(null);
    setResult(null);
    setPhase("connecting");
    try {
      const live = new OnboardingLive({
        onPhase: (nextPhase) => {
          if (session.current === live) {
            setPhase(nextPhase);
          }
        },
        onMessages: (visible, confirmed) => {
          if (session.current === live) {
            setMessages(visible);
            reportMessages.current(confirmed);
          }
        },
        onComplete: (turn) => {
          if (session.current === live) {
            setResult(turn);
            setPhase("ready");
          }
        },
        onError: (message) => {
          if (session.current === live) {
            setError(message);
            setPhase("idle");
          }
        },
      });
      session.current = live;
      void live.start({ name, language });
    } catch {
      close();
      setError(
        "Couldn't start voice. Check your microphone and connection, then restart voice or switch to text."
      );
      setPhase("idle");
    }
  }

  const begin = useEffectEvent(start);
  useEffect(() => {
    if (startOnMount.current) {
      begin();
    }
    window.addEventListener("pagehide", close);
    return () => {
      window.removeEventListener("pagehide", close);
      close();
    };
  }, [close]);

  return {
    phase,
    messages,
    error,
    result,
    start,
    stop,
    pause: () => session.current?.pause(),
    resume: () => session.current?.resume(),
    getInputVolume: () => session.current?.getInputVolume() ?? 0,
    getAnalyser: () => session.current?.getAnalyser() ?? null,
  };
}
